# Diagnosis

The minimal reproduction was run before changing the loader:

```bash
PYTHONPATH=local/drafter-quant python - <<'PY'
import torch
from dquant.quantize import make_real_loader
loader, count = make_real_loader(
    '/data/fast/drafter-quant/data/perfectblend_2048_prepared',
    seq_len=16, num_samples=1, seed=0,
)
x = next(iter(loader))['hidden_states'].cuda()
print(count, tuple(x.shape), x.dtype)
print(torch.amin(x, dim=(0, -1)))
PY
```

Before: `1 (1, 16, 20480) torch.float8_e4m3fn`, then
`NotImplementedError: "min_values_cuda" not implemented for 'Float8_e4m3fn'`.
After: `1 (1, 16, 20480) torch.bfloat16`, with finite CUDA minimum reduction.

Ranked hypotheses and outcomes:

1. The loader bypasses scale application: confirmed. `ArrowDataset` defaults to
   `FileTransfer`; explicitly providing an FP8 transfer applies stored scales to
   both auxiliary and final states. A cast by itself is insufficient.
2. Cache entries are missing or misaligned: no missing files among the 2,027
   prepared rows. The streaming scan checks every row's token IDs against the
   prepared dataset and checks finite decoded states. See `cache_scan.json`.
3. Drafter dimensions or calibration-forward incompatibility remain: the
   Qwen3-8B/DFlash one-sample real and Gaussian runs completed for both schemes;
   all saved activation scales were finite and positive. This does not test
   DSpark, serving kernels, acceptance, or timing validity.

The original regression suite had ten failing cases before the fix. The final
14 cases pass, including BF16 storage, lazy decoding, exact scale restoration,
mask/token alignment, missing scales/files, non-finite/non-positive scales,
shape mismatch, model incompatibility, budget shortfalls, and deterministic
real/Gaussian sample generation.
