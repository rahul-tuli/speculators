# Calibration-input validation

This directory records the resolution evidence for
[Establish a correct, reusable calibration input path](https://github.com/rahul-tuli/speculators/issues/102).
These are plumbing checks, not acceptance, speed, or calibration-quality results.

## Reproduce

From `/workspace/speculators`:

```bash
python -m pytest -q local/drafter-quant/tests/test_calibration.py
PYTHONPATH=local/drafter-quant OMP_NUM_THREADS=4 \
  python local/drafter-quant/wayfinder/calibration-validation/scan_cache.py
python local/drafter-quant/wayfinder/calibration-validation/run_smoke.py
```

`run_smoke.py` refuses to overwrite existing outputs. Select a fresh `OUTPUT`
directory before rerunning it. It runs one 512-token sample per source and scheme,
using cached checkpoints with Hugging Face offline mode. The real source uses
prepared sample 1602 (seed 0), whose first 512 tokens include 34 loss-mask tokens.
Gaussian calibration uses random IDs, Gaussian states, and all-one masks. Those
inputs differ in more than hidden-state distribution; no causal comparison is
claimed here.

## Artifacts

- `cache_scan.json`, `cache_scan.log`: all-row token alignment, finite decoded
  states, budget totals, process peak RSS, and selected sample indices.
- `smoke_results.json`, `*_command.txt`, `*.log`: exact invocations and exit codes
  for FP8/NVFP4 calibration with real/Gaussian inputs.
  `checkpoint_checks.json` verifies finite positive saved scales, including
  activation scales for all 36 calibrated modules in every smoke output.
- `source/`: copies of the calibration implementation at smoke-run startup;
  `final-source/`: final implementation, regression tests, and changed scripts;
  `speculators.patch`, `git_head.txt`, `packages.txt`: workspace revision,
  tracked changes, and installed packages. Local experiment code is untracked,
  so the source copies are essential; a Git diff alone cannot recreate it.
- `drafter_checkpoint_sha256.txt`, `*_checkpoint_sha256.txt`: original drafter
  snapshot and smoke checkpoint hashes.
  `current_target_checkpoint_sha256.txt` hashes the target snapshot currently
  available to calibration, without asserting it was used for historical capture.
- `capture_vllm_command.txt`, `capture_vllm.patch`,
  `capture_checkpoint_sha256.txt`: original cache capture provenance, preserved
  verbatim. The historical checkpoint file records a remote model name, not
  checkpoint content hashes; the exact original target weights cannot be proved
  from that file. No hidden states were recaptured during this task.
- Each smoke output directory includes `calibration_manifest.json` with actual
  sample/token/mask counts and source identity, plus `quant_run_manifest.json`.

The cache header/stat digest detects inventory changes; it is **not** a hash of
all hidden-state tensor payloads. Arrow files have content hashes. Model name,
ordered captured layers, and hidden width are checked against the drafter.
Full experiment run identities and provenance remain the responsibility of
[Establish trustworthy evaluation records and resumable run identities](https://github.com/rahul-tuli/speculators/issues/106).

## Use the preserved cache

The existing Qwen3-8B cache has 2,027 rows. Asking for 2,048 now fails explicitly.
For an agreed 2,027-sample calibration budget, invoke the quantizer directly:

```bash
cd local/drafter-quant
NUM_SAMPLES=2027 bash scripts/30_quantize.sh fp8_w8a8 \
  /data/fast/drafter-quant/data/perfectblend_2048_prepared perfectblend
```

Do not interpret this example as the experiment's chosen budget. That decision
belongs to [Choose calibration comparisons and the claims they can support](https://github.com/rahul-tuli/speculators/issues/104).
The full orchestration script uses its sample count for both preparation and
calibration; direct invocation lets existing preparation keep its original name.
Future captures default to separate target/backend/layer/width/budget paths;
an explicit legacy `PREPARED` override remains usable after validation.
