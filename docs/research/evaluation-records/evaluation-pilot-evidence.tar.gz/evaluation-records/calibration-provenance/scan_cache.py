import json
import resource
import time
from pathlib import Path

import torch
from dquant.quantize import make_real_loader

start = time.monotonic()
loader, n = make_real_loader('/data/fast/drafter-quant/data/perfectblend_2048_prepared', 2048, 2027, 0,
                            expected_target='Qwen/Qwen3-8B', expected_layers=[2,10,18,26,34],
                            expected_hidden_size=4096)
baseline_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
count = tokens = masked = 0
for batch in loader:
    assert batch['hidden_states'].dtype == torch.bfloat16
    assert batch['verifier_last_hidden_states'].dtype == torch.bfloat16
    tokens += batch['input_ids'].numel()
    masked += batch['loss_mask'].sum().item()
    count += 1
    del batch
    if count % 200 == 0:
        print(f'validated {count}/{n}', flush=True)
assert count == n and tokens == loader.dataset.manifest['actual_tokens']
result = {'validated_samples': count, 'validated_tokens': tokens, 'loss_mask_tokens': masked,
          'elapsed_seconds': time.monotonic()-start, 'baseline_maxrss_kib': baseline_rss,
          'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          'manifest': loader.dataset.manifest}
Path(__file__).with_name('cache_scan.json').write_text(json.dumps(result, indent=2)+'\n')
print({k:v for k,v in result.items() if k != 'manifest'}, flush=True)
