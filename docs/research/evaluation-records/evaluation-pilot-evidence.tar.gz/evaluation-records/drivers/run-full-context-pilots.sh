#!/usr/bin/env bash
set -euo pipefail
export HF_HOME=/data/fast/hf_cache HF_HUB_CACHE=/data/fast/hf_cache/hub
export PYTHONPATH=/workspace/speculators/local/drafter-quant
ROOT=/data/fast/drafter-quant/validation/evaluation-records
CKPTS=/data/fast/drafter-quant/validation/calibration-input-20260921
# Let the already running Gaussian pilot finish and clean up its owned server.
while [[ -e /proc/1074621/stat ]] && [[ "$(awk '{print $3}' /proc/1074621/stat)" != Z ]]; do sleep 5; done
ARMS=(fp8-real fp8-gaussian bf16-drafter target-only nvfp4-real nvfp4-gaussian)
PATHS=("$CKPTS/fp8_w8a8-real" "$CKPTS/fp8_w8a8-random" RedHatAI/Qwen3-8B-speculator.dflash none "$CKPTS/nvfp4_w4a4-real" "$CKPTS/nvfp4_w4a4-random")
for ((i=0;i<${#ARMS[@]};i++)); do
  DATASETS=("$ROOT/pilot.jsonl" "$ROOT/pilot-long.jsonl")
  if [[ "${ARMS[$i]}" == nvfp4* ]]; then DATASETS=("$ROOT/pilot-long.jsonl"); fi
  python -m dquant.evaluate_arm --target Qwen/Qwen3-8B --drafter "${PATHS[$i]}" --arm "${ARMS[$i]}" \
    --datasets "${DATASETS[@]}" --manifest "$ROOT/pilot-full-context-manifest.json" \
    --output "$ROOT/full-context-arms" --repeat 0 --order "$i" --phase pilot \
    > "$ROOT/context-${ARMS[$i]}.log" 2>&1
done
