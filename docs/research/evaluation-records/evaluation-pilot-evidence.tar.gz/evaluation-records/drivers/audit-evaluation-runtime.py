import json
from pathlib import Path
from collections import defaultdict
from safetensors import safe_open

root=Path('/data/fast/drafter-quant/validation/evaluation-records/validated-arms')
reports=[]
for path in root.glob('**/runtime-inventory.json'):
    identity=json.loads((path.parent.parent/'run-identity.json').read_text())
    arm=identity['arm']
    models=json.loads(path.read_text())['results'][0]['models']
    modules=models.get('drafter',{})
    quantized={name:m for name,m in modules.items() if m['scheme']!='NoneType'}
    report={'arm':arm,'inventory':str(path),'runtime_quantized_modules':len(quantized)}
    if arm.startswith(('nvfp4','fp8')):
        checkpoint=Path(identity['drafter']['path'])/'model.safetensors'
        groups=defaultdict(list)
        with safe_open(checkpoint,framework='pt',device='cpu') as f:
            for key in f.keys():
                if not key.endswith('.weight_scale'):continue
                prefix=key.removesuffix('.weight_scale')
                runtime='model.'+prefix
                for projection in ['q_proj','k_proj','v_proj']:
                    runtime=runtime.replace('.'+projection,'.qkv_proj')
                for projection in ['gate_proj','up_proj']:
                    runtime=runtime.replace('.'+projection,'.gate_up_proj')
                groups[runtime].append(prefix)
            assert set(groups)==set(quantized),(set(groups)-set(quantized),set(quantized)-set(groups))
            report['export_quantized_modules']=sum(map(len,groups.values()))
            report['module_mapping']=dict(groups)
            report['effective_scales']={}
            if arm.startswith('nvfp4'):
                for runtime, prefixes in groups.items():
                    module=quantized[runtime]
                    actual=module['parameters']
                    input_scale=max(float(f.get_tensor(prefix+'.input_global_scale').max()) for prefix in prefixes)
                    weight_scale=max(float(f.get_tensor(prefix+'.weight_global_scale').max()) for prefix in prefixes)
                    assert abs(actual['input_global_scale_inv']['max']/input_scale-1)<1e-6
                    assert abs(actual['weight_global_scale']['max']*weight_scale-1)<1e-6
                    assert module['use_a16'] is False
                    report['effective_scales'][runtime]={'input_inverse':input_scale,'weight':1/weight_scale}
        for name,module in modules.items():
            if 'embed_tokens' in name or 'lm_head' in name:
                assert module['scheme']=='NoneType'
    finite=json.loads((path.parent/'finite-probe.json').read_text())['results'][0]
    assert finite and all(v['finite'] for v in finite.values())
    assert all('drafter.'+name in finite for name in quantized)
    report['finite_modules_exercised']=len(finite)
    reports.append(report)
(root/'runtime-audit.json').write_text(json.dumps(reports,indent=2)+'\n')
print([(r['arm'],r['runtime_quantized_modules'],r['finite_modules_exercised']) for r in reports])
