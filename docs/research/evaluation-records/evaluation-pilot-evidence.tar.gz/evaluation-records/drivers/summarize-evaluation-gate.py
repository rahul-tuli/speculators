from pathlib import Path
import json
import sys
sys.path.insert(0,'/workspace/speculators/scripts/evaluate')
from point import completed
sys.path.insert(0,'/workspace/speculators/local/drafter-quant')
from dquant.serving_inventory import validate_export_inventory
root=Path('/data/fast/drafter-quant/validation/evaluation-records/full-context-arms')
rows=[]
for identity_path in root.glob('pilot/*/repeat-*/*/run-identity.json'):
 run=identity_path.parent
 servers=list(run.glob('server-*/finished.json'))
 if not servers:continue
 server=servers[-1].parent
 identity=json.loads(identity_path.read_text())
 inventory=json.loads((server/'runtime-inventory.json').read_text())['results'][0]
 finite=json.loads((server/'finite-probe.json').read_text())['results'][0]
 assert finite and all(v['finite'] for v in finite.values())
 audit=None
 if identity['arm'].startswith(('fp8','nvfp4')):
  audit=validate_export_inventory(Path(identity['drafter']['path']),inventory['models']['drafter'])
 record={'arm':identity['arm'],'run_path':str(run),'context':20749,'finite_modules':len(finite),'audit':audit,'points':[]}
 quantized={k:v for k,v in inventory['models'].get('drafter',{}).items() if v['scheme']!='NoneType'}
 record['kernels']=sorted({v for m in quantized.values() for v in m['kernels'].values() if v.endswith('Kernel')})
 for path in run.glob('concurrency-*/*/complete.json'):
  marker=json.loads(path.read_text());attempt=completed(path.parent,marker['identity']);assert attempt
  result=json.loads((attempt/'result.json').read_text())
  bm=json.loads((attempt/'measurement.json').read_text())['benchmarks'][0]
  wm=json.loads((attempt/'warmup.json').read_text())['benchmarks'][0]
  requests=bm['requests']['successful'];assert len(requests)==1
  request=requests[0]
  if path.parent.name=='pilot-long':assert request['input_metrics']['text_tokens']==16653
  record['points'].append({'workload':path.parent.name,'prompt_tokens':request['input_metrics']['text_tokens'],
   'output_tokens':request['output_metrics']['text_tokens'],'request_latency_s':request['request_latency'],
   'warmup_requests':len(wm['requests']['successful']),
   'warmup_latencies_s':[r['request_latency'] for r in wm['requests']['successful']],
   'acceptance':result['acceptance'],'source':str(attempt)})
 assert any(p['workload']=='pilot-long' for p in record['points'])
 rows.append(record)
(root.parent/'gate-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
print([(r['arm'],r['kernels'],[p['workload'] for p in r['points']]) for r in rows])
