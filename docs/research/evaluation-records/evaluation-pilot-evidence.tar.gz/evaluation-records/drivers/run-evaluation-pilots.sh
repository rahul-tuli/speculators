#!/usr/bin/env bash
set -euo pipefail
export HF_HOME=/data/fast/hf_cache HF_HUB_CACHE=/data/fast/hf_cache/hub
export PYTHONPATH=/workspace/speculators/local/drafter-quant
ROOT=/data/fast/drafter-quant/validation/evaluation-records
CKPTS=/data/fast/drafter-quant/validation/calibration-input-20260921
ARMS=(nvfp4-real nvfp4-gaussian fp8-real fp8-gaussian bf16-drafter target-only)
PATHS=("$CKPTS/nvfp4_w4a4-real" "$CKPTS/nvfp4_w4a4-random" "$CKPTS/fp8_w8a8-real" "$CKPTS/fp8_w8a8-random" RedHatAI/Qwen3-8B-speculator.dflash none)
for ((i=0;i<${#ARMS[@]};i++)); do
  python -m dquant.evaluate_arm --target Qwen/Qwen3-8B --drafter "${PATHS[$i]}" --arm "${ARMS[$i]}" \
    --datasets "$ROOT/pilot.jsonl" --manifest "$ROOT/pilot-manifest.json" \
    --output "$ROOT/validated-arms" --repeat 0 --order "$i" --phase pilot \
    > "$ROOT/final-${ARMS[$i]}.log" 2>&1
done
