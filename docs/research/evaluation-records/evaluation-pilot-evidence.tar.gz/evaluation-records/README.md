# Evidence bundle

These are bounded serving pilots, not the full-budget experiment. Calibration exports have one 512-token sequence. Runtime inventories, effective fused scales, finite-output checks, raw counters, per-request numerical measurements, commands, patches, checkpoint hashes, package/source identities, manifests and calibration provenance are retained.

`measurement.public.json` and `warmup.public.json` omit prompt/output payloads and replace them with hashes. Original raw records remain at the local paths in runs.json; complete.json retains original artifact hashes. Do not use public derivatives as resumable runs. Materialized benchmark text is not redistributed. Dataset manifests identify every first prompt without containing its text. Reconstruct data from the pinned upstream preparation and source IDs.

Initial failed attempts (cache quota, pre-postprocessing quantized KV construction, scalar inventory hashing, and overlapping startup) remain local and are described in the accompanying report. No failed attempt is treated as a complete point.
